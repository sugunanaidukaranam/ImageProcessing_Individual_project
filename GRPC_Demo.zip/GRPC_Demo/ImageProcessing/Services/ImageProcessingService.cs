﻿using Grpc.Core;
using ImageProcessing.Protos;
using SixLabors.ImageSharp;
using System.Drawing;
using System.IO;
using System.Collections.Generic;
using SixLabors.ImageSharp.Processing;

namespace ImageProcessing.Services
{
    public class ImageProcessingService : ImageProcessing.Protos.ImageProcessingService.ImageProcessingServiceBase
    {
        private readonly ILogger<ImageProcessingService> _logger;

        public ImageProcessingService(ILogger<ImageProcessingService> logger)
        {
            _logger = logger;
        }

        public override Task<ProcessImageResponse> ProcessImage(ProcessImageRequest request, ServerCallContext context)
        {
            try
            {
                // Load image from byte array
                using (MemoryStream inStream = new MemoryStream(request.ImageData.ToByteArray()))
                using (Image image = Image.Load(inStream))
                {
                    // Apply each image processing operation
                    foreach (var operation in request.Operations)
                    {
                        switch (operation)
                        {
                            case Protos.ImageOperation.FlipHorizontal:
                                image.Mutate(x => x.Flip(FlipMode.Horizontal));
                                break;
                            case Protos.ImageOperation.FlipVertical:
                                image.Mutate(x => x.Flip(FlipMode.Vertical));
                                break;
                            case Protos.ImageOperation.Rotate:
                                image.Mutate(x => x.Rotate(request.RotationAngle));
                                break;
                            case Protos.ImageOperation.ConvertToGrayscale:
                                image.Mutate(x => x.Grayscale());
                                break;
                            case Protos.ImageOperation.Resize:
                                image.Mutate(x => x.Resize(request.Width,request.Height));
                                break;
                            case Protos.ImageOperation.GenerateThumbnail:
                                image.Mutate(x => x.Resize(100, 100));
                                break;
                            case Protos.ImageOperation.RotateLeft:
                                image.Mutate(x => x.Rotate(request.RotationAngle));
                                break;
                            case Protos.ImageOperation.RotateRight:
                                image.Mutate(x => x.Rotate(request.RotationAngle));
                                break;
                            default:
                                throw new ArgumentException("Invalid image operation specified.");
                        }
                    }

                    // Save processed image to a new memory stream
                    using (MemoryStream outStream = new MemoryStream())
                    {
                        image.Save(outStream, new SixLabors.ImageSharp.Formats.Jpeg.JpegEncoder());
                        return Task.FromResult(new ProcessImageResponse
                        {
                            ProcessedImageData = Google.Protobuf.ByteString.CopyFrom(outStream.ToArray())
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing image: {ex.Message}");
                throw new RpcException(new Status(StatusCode.Internal, "Error processing image"));
            }

        }



    }
}
