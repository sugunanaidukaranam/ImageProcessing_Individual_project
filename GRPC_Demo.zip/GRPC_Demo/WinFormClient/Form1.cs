using Grpc.Core;
using Grpc.Net.Client;
using ImageProcessing.Protos;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace WinFormClient
{
    public partial class Form1 : Form
    {
        private ImageProcessingService.ImageProcessingServiceClient _client;
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox= false;
            // Create a gRPC channel to the specified host and port
            var channel = GrpcChannel.ForAddress("http://localhost:5285");

            // Instantiate the gRPC client using the channel
            _client = new ImageProcessingService.ImageProcessingServiceClient(channel);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            // Set filter to allow only image files
            openFileDialog1.Filter = "Image Files (*.bmp; *.jpg; *.jpeg; *.png)|*.bmp;*.jpg;*.jpeg;*.png|All files (*.*)|*.*";

            // Load image from selected file
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                int angle = 0;
                int width = 0, height = 0;
                // Check if the selected file is an image
                if (!IsImageFile(filePath))
                {
                    MessageBox.Show("Please select an image file.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                try
                { 
                    byte[] imageData = File.ReadAllBytes(filePath);
                    // Get selected operations
                    List<ImageOperation> selectedOperations = GetSelectedOperations();
                    if (checkBoxRotate.Checked)
                    {
                        if (txtAngle.Text.Length <= 0)
                        {
                            MessageBox.Show("please specify angle");
                            return;
                        }
                        else
                        {
                            angle= Convert.ToInt32(txtAngle.Text);
                        }
                    }
                    if (checkBoxResize.Checked)
                    {
                        if (txtWidth.Text.Length <= 0)
                        {
                            MessageBox.Show("please specify width");
                            return;
                        }
                        else
                        {
                            width= Convert.ToInt32(txtWidth.Text);
                        }
                        if (txtHeight.Text.Length <= 0)
                        {
                            MessageBox.Show("please specify height");
                            return;
                        }
                        else
                        {
                            height = Convert.ToInt32(txtHeight.Text);
                        }
                    }
                    if (checkBoxRotateLeft.Checked)
                    {
                        if (txtAngle.Text.Length <= 0)
                        {
                            MessageBox.Show("please specify angle");
                            return;
                        }
                        else
                        {
                            angle= Convert.ToInt32(txtAngle.Text);
                        }
                    }
                    if (checkBoxRotateRight.Checked)
                    {
                        if (txtAngle.Text.Length <= 0)
                        {
                            MessageBox.Show("please specify angle");
                            return;
                        }
                        else
                        {
                            angle= Convert.ToInt32(txtAngle.Text);
                        }
                    }
                    // Call the ProcessImage method with selected operations
                    var response = _client.ProcessImage(new ProcessImageRequest
                    {
                        ImageData = Google.Protobuf.ByteString.CopyFrom(imageData),
                        Operations = { selectedOperations },
                        RotationAngle = angle,
                        Width= width,
                        Height= height,
                    });


                    // Display processed image if response is successful
                    if (response != null)
                    {
                        lblText.Text = "Processed Image";
                        string tempFileName = Path.GetTempFileName();
                        File.WriteAllBytes(tempFileName, response.ProcessedImageData.ToByteArray());
                        pictureBox1.ImageLocation = tempFileName;
                    }
                    else
                    {
                        MessageBox.Show("Error processing image.");
                    }
                }
                catch(RpcException ex)
                {
                    // Handle gRPC errors returned by the server
                    MessageBox.Show($"Error processing image: {ex.Status.Detail}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Method to check if a file is an image
        private bool IsImageFile(string filePath)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    using (Image image = Image.FromStream(fs))
                    {
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }


        

        // Method to get the selected image processing operations from UI
        private List<ImageOperation> GetSelectedOperations()
        {
            List<ImageOperation> selectedOperations = new List<ImageOperation>();

            if (checkBoxFlipHorizontal.Checked)
                selectedOperations.Add(ImageOperation.FlipHorizontal);
            if (checkBoxFlipVertical.Checked)
                selectedOperations.Add(ImageOperation.FlipVertical);
            if (checkBoxRotate.Checked) { 
                selectedOperations.Add(ImageOperation.Rotate);
            }
            if (checkBoxConvertToGrayscale.Checked)
                selectedOperations.Add(ImageOperation.ConvertToGrayscale);
            if (checkBoxResize.Checked)
            {
                selectedOperations.Add(ImageOperation.Resize);
            }
            if (checkBoxGenerateThumbnail.Checked)
                selectedOperations.Add(ImageOperation.GenerateThumbnail);
            if (checkBoxRotateLeft.Checked) { 
                selectedOperations.Add(ImageOperation.RotateLeft);
            }
            if (checkBoxRotateRight.Checked) { 
                selectedOperations.Add(ImageOperation.RotateRight);
            }

            return selectedOperations;
        }


    }
}