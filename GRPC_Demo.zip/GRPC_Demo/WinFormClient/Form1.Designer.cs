﻿namespace WinFormClient
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnProcess = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblText = new System.Windows.Forms.Label();
            this.checkBoxFlipHorizontal = new System.Windows.Forms.CheckBox();
            this.checkBoxFlipVertical = new System.Windows.Forms.CheckBox();
            this.checkBoxRotate = new System.Windows.Forms.CheckBox();
            this.checkBoxConvertToGrayscale = new System.Windows.Forms.CheckBox();
            this.checkBoxResize = new System.Windows.Forms.CheckBox();
            this.checkBoxGenerateThumbnail = new System.Windows.Forms.CheckBox();
            this.checkBoxRotateLeft = new System.Windows.Forms.CheckBox();
            this.checkBoxRotateRight = new System.Windows.Forms.CheckBox();
            this.txtAngle = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(20, 359);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(131, 40);
            this.btnProcess.TabIndex = 8;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(307, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(591, 671);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(495, 9);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(0, 30);
            this.lblText.TabIndex = 10;
            // 
            // checkBoxFlipHorizontal
            // 
            this.checkBoxFlipHorizontal.AutoSize = true;
            this.checkBoxFlipHorizontal.Location = new System.Drawing.Point(23, 42);
            this.checkBoxFlipHorizontal.Name = "checkBoxFlipHorizontal";
            this.checkBoxFlipHorizontal.Size = new System.Drawing.Size(167, 34);
            this.checkBoxFlipHorizontal.TabIndex = 11;
            this.checkBoxFlipHorizontal.Text = "FlipHorizontal";
            this.checkBoxFlipHorizontal.UseVisualStyleBackColor = true;
            // 
            // checkBoxFlipVertical
            // 
            this.checkBoxFlipVertical.AutoSize = true;
            this.checkBoxFlipVertical.Location = new System.Drawing.Point(21, 79);
            this.checkBoxFlipVertical.Name = "checkBoxFlipVertical";
            this.checkBoxFlipVertical.Size = new System.Drawing.Size(139, 34);
            this.checkBoxFlipVertical.TabIndex = 12;
            this.checkBoxFlipVertical.Text = "FlipVertical";
            this.checkBoxFlipVertical.UseVisualStyleBackColor = true;
            // 
            // checkBoxRotate
            // 
            this.checkBoxRotate.AutoSize = true;
            this.checkBoxRotate.Location = new System.Drawing.Point(20, 119);
            this.checkBoxRotate.Name = "checkBoxRotate";
            this.checkBoxRotate.Size = new System.Drawing.Size(99, 34);
            this.checkBoxRotate.TabIndex = 13;
            this.checkBoxRotate.Text = "Rotate";
            this.checkBoxRotate.UseVisualStyleBackColor = true;
            // 
            // checkBoxConvertToGrayscale
            // 
            this.checkBoxConvertToGrayscale.AutoSize = true;
            this.checkBoxConvertToGrayscale.Location = new System.Drawing.Point(21, 159);
            this.checkBoxConvertToGrayscale.Name = "checkBoxConvertToGrayscale";
            this.checkBoxConvertToGrayscale.Size = new System.Drawing.Size(222, 34);
            this.checkBoxConvertToGrayscale.TabIndex = 14;
            this.checkBoxConvertToGrayscale.Text = "ConvertToGrayScale";
            this.checkBoxConvertToGrayscale.UseVisualStyleBackColor = true;
            // 
            // checkBoxResize
            // 
            this.checkBoxResize.AutoSize = true;
            this.checkBoxResize.Location = new System.Drawing.Point(23, 199);
            this.checkBoxResize.Name = "checkBoxResize";
            this.checkBoxResize.Size = new System.Drawing.Size(97, 34);
            this.checkBoxResize.TabIndex = 15;
            this.checkBoxResize.Text = "Resize";
            this.checkBoxResize.UseVisualStyleBackColor = true;
            // 
            // checkBoxGenerateThumbnail
            // 
            this.checkBoxGenerateThumbnail.AutoSize = true;
            this.checkBoxGenerateThumbnail.Location = new System.Drawing.Point(22, 239);
            this.checkBoxGenerateThumbnail.Name = "checkBoxGenerateThumbnail";
            this.checkBoxGenerateThumbnail.Size = new System.Drawing.Size(221, 34);
            this.checkBoxGenerateThumbnail.TabIndex = 16;
            this.checkBoxGenerateThumbnail.Text = "GenerateThumbnail";
            this.checkBoxGenerateThumbnail.UseVisualStyleBackColor = true;
            // 
            // checkBoxRotateLeft
            // 
            this.checkBoxRotateLeft.AutoSize = true;
            this.checkBoxRotateLeft.Location = new System.Drawing.Point(23, 279);
            this.checkBoxRotateLeft.Name = "checkBoxRotateLeft";
            this.checkBoxRotateLeft.Size = new System.Drawing.Size(134, 34);
            this.checkBoxRotateLeft.TabIndex = 17;
            this.checkBoxRotateLeft.Text = "RotateLeft";
            this.checkBoxRotateLeft.UseVisualStyleBackColor = true;
            // 
            // checkBoxRotateRight
            // 
            this.checkBoxRotateRight.AutoSize = true;
            this.checkBoxRotateRight.Location = new System.Drawing.Point(22, 319);
            this.checkBoxRotateRight.Name = "checkBoxRotateRight";
            this.checkBoxRotateRight.Size = new System.Drawing.Size(148, 34);
            this.checkBoxRotateRight.TabIndex = 18;
            this.checkBoxRotateRight.Text = "RotateRight";
            this.checkBoxRotateRight.UseVisualStyleBackColor = true;
            // 
            // txtAngle
            // 
            this.txtAngle.Location = new System.Drawing.Point(190, 297);
            this.txtAngle.Name = "txtAngle";
            this.txtAngle.Size = new System.Drawing.Size(67, 35);
            this.txtAngle.TabIndex = 19;
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(126, 199);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(67, 35);
            this.txtWidth.TabIndex = 20;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(214, 199);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(67, 35);
            this.txtHeight.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 799);
            this.Controls.Add(this.txtHeight);
            this.Controls.Add(this.txtWidth);
            this.Controls.Add(this.txtAngle);
            this.Controls.Add(this.checkBoxRotateRight);
            this.Controls.Add(this.checkBoxRotateLeft);
            this.Controls.Add(this.checkBoxGenerateThumbnail);
            this.Controls.Add(this.checkBoxResize);
            this.Controls.Add(this.checkBoxConvertToGrayscale);
            this.Controls.Add(this.checkBoxRotate);
            this.Controls.Add(this.checkBoxFlipVertical);
            this.Controls.Add(this.checkBoxFlipHorizontal);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnProcess);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button btnProcess;
        private OpenFileDialog openFileDialog1;
        private PictureBox pictureBox1;
        private Label lblText;
        private CheckBox checkBoxFlipHorizontal;
        private CheckBox checkBoxFlipVertical;
        private CheckBox checkBoxRotate;
        private CheckBox checkBoxConvertToGrayscale;
        private CheckBox checkBoxResize;
        private CheckBox checkBoxGenerateThumbnail;
        private CheckBox checkBoxRotateLeft;
        private CheckBox checkBoxRotateRight;
        private TextBox txtAngle;
        private TextBox txtWidth;
        private TextBox txtHeight;
    }
}