﻿using Google.Protobuf;
using Grpc.Core;
using System;
using ImageProcessing.Protos;
using System.Threading.Channels;
using GrpcClient;

namespace YourNamespace
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Instantiate the ImageProcessingClient with the gRPC service endpoint
            var client = new ImageProcessingClient("localhost", 5285);

            // Example: Load image data from file (replace this with your own image loading logic)
            byte[] imageData = System.IO.File.ReadAllBytes("D:\\grpc_1.png");

            Console.WriteLine("Please choose an option:");
            Console.WriteLine("0. Option flip horizontal");
            Console.WriteLine("1. Option flip vertical");
            Console.WriteLine("2. Option rotate");
            Console.WriteLine("3. Option convert to grayscale");
            Console.WriteLine("4. Option resize");
            Console.WriteLine("5. Option generate thumbnail");
            Console.WriteLine("6. Option rotate left");
            Console.WriteLine("7. Option rotate right");

            string input = Console.ReadLine();

            ImageOperation imgOption = ImageOperation.RotateLeft; 

            switch (input)
            {
                case "0":
                    imgOption =  ImageOperation.FlipHorizontal;
                    break;
                case "1":
                    imgOption = ImageOperation.FlipVertical;
                    break;
                case "2":
                    imgOption = ImageOperation.Rotate;
                    break;
                case "3":
                    imgOption = ImageOperation.ConvertToGrayscale;
                    break;
                case "4":
                    imgOption = ImageOperation.Resize;
                    break;
                case "5":
                    imgOption = ImageOperation.GenerateThumbnail;
                    break;
                case "6":
                    imgOption = ImageOperation.RotateLeft;
                    break;
                case "7":
                    imgOption = ImageOperation.RotateRight;
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;
            }

            // Call the ProcessImage method with the desired image processing operation
            var response = client.ProcessImage(imageData, imgOption, width: 100, height: 100);

            if (response != null)
            {
                // Handle the response (for example, save the processed image to a file)
                byte[] processedImageData = response.ProcessedImageData.ToByteArray();
                System.IO.File.WriteAllBytes("processed_image.jpg", processedImageData);

                Console.WriteLine("Image processing completed successfully.");

                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Error occurred while processing the image.");
                Console.ReadLine();
            }

        }

    }
}
