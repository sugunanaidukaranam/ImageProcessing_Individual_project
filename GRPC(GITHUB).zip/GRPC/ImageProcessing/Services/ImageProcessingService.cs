﻿using Grpc.Core;
using ImageProcessing.Protos;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.IO;
using System.Threading.Tasks;

namespace ImageProcessing.Services
{
    public class ImageProcessingService : ImageProcessing.Protos.ImageProcessingService.ImageProcessingServiceBase
    {
        private readonly ILogger<ImageProcessingService> _logger;

        public ImageProcessingService(ILogger<ImageProcessingService> logger)
        {
            _logger = logger;
        }

        public override Task<ProcessImageResponse> ProcessImage(ProcessImageRequest request, ServerCallContext context)
        {
            try
            {
                // Load image from byte array
                using (MemoryStream inStream = new MemoryStream(request.ImageData.ToByteArray()))
                using (Image image = Image.Load(inStream))
                {
                    // Apply image processing based on operation
                    switch (request.Operation)
                    {
                        case (Protos.ImageOperation)ImageOperation.FlipHorizontal:
                            image.Mutate(x => x.Flip(FlipMode.Horizontal));
                            break;
                        case (Protos.ImageOperation)ImageOperation.FlipVertical:
                            image.Mutate(x => x.Flip(FlipMode.Vertical));
                            break;
                        case (Protos.ImageOperation)ImageOperation.Rotate:
                            image.Mutate(x => x.Rotate(request.RotationAngle));
                            break;
                        case (Protos.ImageOperation)ImageOperation.ConvertToGrayscale:
                            image.Mutate(x => x.Grayscale());
                            break;
                        case (Protos.ImageOperation)ImageOperation.Resize:
                            image.Mutate(x => x.Resize(request.Width, request.Height));
                            break;
                        case (Protos.ImageOperation)ImageOperation.GenerateThumbnail:
                            image.Mutate(x => x.Resize(100, 100));
                            break;
                        case (Protos.ImageOperation)ImageOperation.RotateLeft:
                            image.Mutate(x => x.Rotate(-90));
                            break;
                        case (Protos.ImageOperation)ImageOperation.RotateRight:
                            image.Mutate(x => x.Rotate(90));
                            break;
                        default:
                            throw new ArgumentException("Invalid image operation specified.");
                    }

                    // Save processed image to a new memory stream
                    using (MemoryStream outStream = new MemoryStream())
                    {
                        image.Save(outStream, new SixLabors.ImageSharp.Formats.Jpeg.JpegEncoder());
                        return Task.FromResult(new ProcessImageResponse
                        {
                            ProcessedImageData = Google.Protobuf.ByteString.CopyFrom(outStream.ToArray())
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing image: {ex.Message}");
                throw new RpcException(new Status(StatusCode.Internal, "Error processing image"));
            }
        }
    }
}

public enum ImageOperation
{
    FlipHorizontal=0,
    FlipVertical=1,
    Rotate=2,
    ConvertToGrayscale=3,
    Resize=4,
    GenerateThumbnail=5,
    RotateLeft=6,
    RotateRight=7
}
