﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Grpc.Core;
using Grpc.Net.Client;
using ImageProcessing.Protos;

namespace GrpcClient
{
    internal class ImageProcessingClient
    {
        private readonly ImageProcessingService.ImageProcessingServiceClient _client;

        public ImageProcessingClient(string host, int port)
        {
            // Create a gRPC channel to the specified host and port
            var channel = GrpcChannel.ForAddress($"http://{host}:{port}");

            // Instantiate the gRPC client using the channel
            _client = new ImageProcessingService.ImageProcessingServiceClient(channel);
        }

        public ProcessImageResponse ProcessImage(byte[] imageData, ImageOperation operation, int rotationAngle = 0, int width = 0, int height = 0)
        {
            // Prepare the request message
            var request = new ProcessImageRequest
            {
                ImageData = Google.Protobuf.ByteString.CopyFrom(imageData),
                Operation = operation,
                RotationAngle = rotationAngle,
                Width = width,
                Height = height
            };

            try
            {
                // Call the ProcessImage method on the gRPC client
                var response = _client.ProcessImage(request);
                return response;
            }
            catch (RpcException ex)
            {
                // Handle gRPC errors
                Console.WriteLine($"Error calling ProcessImage: {ex.Status.Detail}");
                return null;
            }
        }

    }
}
