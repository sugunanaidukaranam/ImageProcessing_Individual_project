﻿namespace WinFormClient
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioButtonFlipHorizontal = new System.Windows.Forms.RadioButton();
            this.radioButtonFlipVertical = new System.Windows.Forms.RadioButton();
            this.radioButtonRotate = new System.Windows.Forms.RadioButton();
            this.radioButtonConvertToGrayscale = new System.Windows.Forms.RadioButton();
            this.radioButtonResize = new System.Windows.Forms.RadioButton();
            this.radioButtonGenerateThumbnail = new System.Windows.Forms.RadioButton();
            this.radioButtonRotateLeft = new System.Windows.Forms.RadioButton();
            this.radioButtonRotateRight = new System.Windows.Forms.RadioButton();
            this.btnProcess = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblText = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButtonFlipHorizontal
            // 
            this.radioButtonFlipHorizontal.AutoSize = true;
            this.radioButtonFlipHorizontal.Location = new System.Drawing.Point(21, 39);
            this.radioButtonFlipHorizontal.Name = "radioButtonFlipHorizontal";
            this.radioButtonFlipHorizontal.Size = new System.Drawing.Size(166, 34);
            this.radioButtonFlipHorizontal.TabIndex = 0;
            this.radioButtonFlipHorizontal.TabStop = true;
            this.radioButtonFlipHorizontal.Text = "FlipHorizontal";
            this.radioButtonFlipHorizontal.UseVisualStyleBackColor = true;
            // 
            // radioButtonFlipVertical
            // 
            this.radioButtonFlipVertical.AutoSize = true;
            this.radioButtonFlipVertical.Location = new System.Drawing.Point(21, 79);
            this.radioButtonFlipVertical.Name = "radioButtonFlipVertical";
            this.radioButtonFlipVertical.Size = new System.Drawing.Size(138, 34);
            this.radioButtonFlipVertical.TabIndex = 1;
            this.radioButtonFlipVertical.TabStop = true;
            this.radioButtonFlipVertical.Text = "FlipVertical";
            this.radioButtonFlipVertical.UseVisualStyleBackColor = true;
            // 
            // radioButtonRotate
            // 
            this.radioButtonRotate.AutoSize = true;
            this.radioButtonRotate.Location = new System.Drawing.Point(21, 119);
            this.radioButtonRotate.Name = "radioButtonRotate";
            this.radioButtonRotate.Size = new System.Drawing.Size(98, 34);
            this.radioButtonRotate.TabIndex = 2;
            this.radioButtonRotate.TabStop = true;
            this.radioButtonRotate.Text = "Rotate";
            this.radioButtonRotate.UseVisualStyleBackColor = true;
            // 
            // radioButtonConvertToGrayscale
            // 
            this.radioButtonConvertToGrayscale.AutoSize = true;
            this.radioButtonConvertToGrayscale.Location = new System.Drawing.Point(21, 159);
            this.radioButtonConvertToGrayscale.Name = "radioButtonConvertToGrayscale";
            this.radioButtonConvertToGrayscale.Size = new System.Drawing.Size(219, 34);
            this.radioButtonConvertToGrayscale.TabIndex = 3;
            this.radioButtonConvertToGrayscale.TabStop = true;
            this.radioButtonConvertToGrayscale.Text = "ConvertToGrayscale";
            this.radioButtonConvertToGrayscale.UseVisualStyleBackColor = true;
            // 
            // radioButtonResize
            // 
            this.radioButtonResize.AutoSize = true;
            this.radioButtonResize.Location = new System.Drawing.Point(21, 199);
            this.radioButtonResize.Name = "radioButtonResize";
            this.radioButtonResize.Size = new System.Drawing.Size(96, 34);
            this.radioButtonResize.TabIndex = 4;
            this.radioButtonResize.TabStop = true;
            this.radioButtonResize.Text = "Resize";
            this.radioButtonResize.UseVisualStyleBackColor = true;
            // 
            // radioButtonGenerateThumbnail
            // 
            this.radioButtonGenerateThumbnail.AutoSize = true;
            this.radioButtonGenerateThumbnail.Location = new System.Drawing.Point(20, 239);
            this.radioButtonGenerateThumbnail.Name = "radioButtonGenerateThumbnail";
            this.radioButtonGenerateThumbnail.Size = new System.Drawing.Size(220, 34);
            this.radioButtonGenerateThumbnail.TabIndex = 5;
            this.radioButtonGenerateThumbnail.TabStop = true;
            this.radioButtonGenerateThumbnail.Text = "GenerateThumbnail";
            this.radioButtonGenerateThumbnail.UseVisualStyleBackColor = true;
            // 
            // radioButtonRotateLeft
            // 
            this.radioButtonRotateLeft.AutoSize = true;
            this.radioButtonRotateLeft.Location = new System.Drawing.Point(20, 279);
            this.radioButtonRotateLeft.Name = "radioButtonRotateLeft";
            this.radioButtonRotateLeft.Size = new System.Drawing.Size(133, 34);
            this.radioButtonRotateLeft.TabIndex = 6;
            this.radioButtonRotateLeft.TabStop = true;
            this.radioButtonRotateLeft.Text = "RotateLeft";
            this.radioButtonRotateLeft.UseVisualStyleBackColor = true;
            // 
            // radioButtonRotateRight
            // 
            this.radioButtonRotateRight.AutoSize = true;
            this.radioButtonRotateRight.Location = new System.Drawing.Point(20, 319);
            this.radioButtonRotateRight.Name = "radioButtonRotateRight";
            this.radioButtonRotateRight.Size = new System.Drawing.Size(147, 34);
            this.radioButtonRotateRight.TabIndex = 7;
            this.radioButtonRotateRight.TabStop = true;
            this.radioButtonRotateRight.Text = "RotateRight";
            this.radioButtonRotateRight.UseVisualStyleBackColor = true;
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(21, 372);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(131, 40);
            this.btnProcess.TabIndex = 8;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(246, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(650, 728);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(495, 9);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(0, 30);
            this.lblText.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 799);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.radioButtonRotateRight);
            this.Controls.Add(this.radioButtonRotateLeft);
            this.Controls.Add(this.radioButtonGenerateThumbnail);
            this.Controls.Add(this.radioButtonResize);
            this.Controls.Add(this.radioButtonConvertToGrayscale);
            this.Controls.Add(this.radioButtonRotate);
            this.Controls.Add(this.radioButtonFlipVertical);
            this.Controls.Add(this.radioButtonFlipHorizontal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RadioButton radioButtonFlipHorizontal;
        private RadioButton radioButtonFlipVertical;
        private RadioButton radioButtonRotate;
        private RadioButton radioButtonConvertToGrayscale;
        private RadioButton radioButtonResize;
        private RadioButton radioButtonGenerateThumbnail;
        private RadioButton radioButtonRotateLeft;
        private RadioButton radioButtonRotateRight;
        private Button btnProcess;
        private OpenFileDialog openFileDialog1;
        private PictureBox pictureBox1;
        private Label lblText;
    }
}