using Grpc.Core;
using Grpc.Net.Client;
using ImageProcessing.Protos;
using System.Windows.Forms;

namespace WinFormClient
{
    public partial class Form1 : Form
    {
        private ImageProcessingService.ImageProcessingServiceClient _client;
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox= false;
            // Create a gRPC channel to the specified host and port
            var channel = GrpcChannel.ForAddress("http://localhost:5285");

            // Instantiate the gRPC client using the channel
            _client = new ImageProcessingService.ImageProcessingServiceClient(channel);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            // Load image from selected file
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                byte[] imageData = File.ReadAllBytes(filePath);
                //lblText.Text = "Original Image";
                //File.WriteAllBytes(filePath, imageData);
                ////Image image = Image.FromFile(filePath);
                //pictureBox1.ImageLocation = filePath;
                //System.Threading.Thread.Sleep(3000);
                // Call the ProcessImage method with selected operation
                var response = _client.ProcessImage(new ProcessImageRequest
                {
                    ImageData = Google.Protobuf.ByteString.CopyFrom(imageData),
                    Operation = GetSelectedOperation(),
                    RotationAngle = 0,
                    Width = 100,
                    Height = 100
                });

                // Display processed image if response is successful
                if (response != null)
                {
                    lblText.Text = "Processed Image";
                    string tempFileName = Path.GetTempFileName();
                    File.WriteAllBytes(tempFileName, response.ProcessedImageData.ToByteArray());
                    pictureBox1.ImageLocation = tempFileName;
                }
                else
                {
                    MessageBox.Show("Error processing image.");
                }
            }
        }

        // Method to get the selected image processing operation from UI
        private ImageOperation GetSelectedOperation()
        {
            if (radioButtonFlipHorizontal.Checked)
                return ImageOperation.FlipHorizontal;
            else if (radioButtonFlipVertical.Checked)
                return ImageOperation.FlipVertical;
            else if (radioButtonRotate.Checked)
                return ImageOperation.Rotate;
            else if (radioButtonConvertToGrayscale.Checked)
                return ImageOperation.ConvertToGrayscale;
            else if (radioButtonResize.Checked)
                return ImageOperation.Resize;
            else if (radioButtonGenerateThumbnail.Checked)
                return ImageOperation.GenerateThumbnail;
            else if (radioButtonRotateLeft.Checked)
                return ImageOperation.RotateLeft;
            else if (radioButtonRotateRight.Checked)
                return ImageOperation.RotateRight;
            else
                throw new Exception("No operation selected.");
        }

    }
}